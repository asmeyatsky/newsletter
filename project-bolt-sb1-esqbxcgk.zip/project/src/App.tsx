import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './contexts/AppContext';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Dashboard from './pages/Dashboard';
import ResumePage from './pages/ResumePage';
import ArticlesPage from './pages/ArticlesPage';
import EmailsPage from './pages/EmailsPage';
import NewsletterPage from './pages/NewsletterPage';

function App() {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen flex flex-col bg-gray-50">
          <Header />
          <main className="flex-grow pt-24 pb-16">
            <div className="container mx-auto px-4">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/resume" element={<ResumePage />} />
                <Route path="/articles" element={<ArticlesPage />} />
                <Route path="/emails" element={<EmailsPage />} />
                <Route path="/newsletter" element={<NewsletterPage />} />
              </Routes>
            </div>
          </main>
          <Footer />
        </div>
      </Router>
    </AppProvider>
  );
}

export default App;