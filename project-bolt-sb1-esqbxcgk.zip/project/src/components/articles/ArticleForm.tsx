import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import Card, { CardHeader, CardContent, CardFooter } from '../common/Card';
import Button from '../common/Button';
import { generateId } from '../../utils/helpers';
import { Article } from '../../types';
import { Check, X } from 'lucide-react';

interface ArticleFormProps {
  onCancel: () => void;
  editArticle?: Article;
}

const ArticleForm: React.FC<ArticleFormProps> = ({ onCancel, editArticle }) => {
  const { addArticle, updateArticle } = useApp();
  const [formData, setFormData] = useState<Omit<Article, 'id'>>({
    title: editArticle?.title || '',
    summary: editArticle?.summary || '',
    publishDate: editArticle?.publishDate || new Date().toISOString().split('T')[0],
    url: editArticle?.url || '',
    source: 'linkedin',
    featured: editArticle?.featured || false
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is updated
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!formData.summary.trim()) {
      newErrors.summary = 'Summary is required';
    }
    
    if (!formData.publishDate) {
      newErrors.publishDate = 'Publish date is required';
    }
    
    if (!formData.url.trim()) {
      newErrors.url = 'URL is required';
    } else if (!isValidUrl(formData.url)) {
      newErrors.url = 'Please enter a valid URL';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidUrl = (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    if (editArticle) {
      updateArticle(editArticle.id, formData);
    } else {
      const newArticle: Article = {
        id: generateId(),
        ...formData
      };
      addArticle(newArticle);
    }
    
    onCancel();
  };

  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-800">
          {editArticle ? 'Edit Article' : 'Add New Article'}
        </h2>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                className={`w-full rounded-md ${
                  errors.title 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
                placeholder="Article title"
              />
              {errors.title && (
                <p className="mt-1 text-sm text-red-600">{errors.title}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Summary
              </label>
              <textarea
                name="summary"
                value={formData.summary}
                onChange={handleChange}
                rows={3}
                className={`w-full rounded-md ${
                  errors.summary 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
                placeholder="Brief summary of the article"
              />
              {errors.summary && (
                <p className="mt-1 text-sm text-red-600">{errors.summary}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Publication Date
              </label>
              <input
                type="date"
                name="publishDate"
                value={formData.publishDate}
                onChange={handleChange}
                className={`w-full rounded-md ${
                  errors.publishDate 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
              />
              {errors.publishDate && (
                <p className="mt-1 text-sm text-red-600">{errors.publishDate}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                URL
              </label>
              <input
                type="text"
                name="url"
                value={formData.url}
                onChange={handleChange}
                className={`w-full rounded-md ${
                  errors.url 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
                placeholder="https://linkedin.com/pulse/your-article"
              />
              {errors.url && (
                <p className="mt-1 text-sm text-red-600">{errors.url}</p>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="featured"
                name="featured"
                checked={formData.featured}
                onChange={handleCheckboxChange}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
              <label htmlFor="featured" className="text-sm font-medium text-gray-700">
                Feature this article in newsletter
              </label>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end space-x-3">
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
            leftIcon={<X className="h-4 w-4" />}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            leftIcon={<Check className="h-4 w-4" />}
          >
            {editArticle ? 'Update Article' : 'Add Article'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default ArticleForm;