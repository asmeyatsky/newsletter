import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import Card, { CardHeader, CardContent } from '../common/Card';
import { formatDate, sortArticlesByDate } from '../../utils/helpers';
import { Article } from '../../types';
import Button from '../common/Button';
import { Plus, Edit2, Trash2, Star, StarOff } from 'lucide-react';
import ArticleForm from './ArticleForm';

const ArticleList: React.FC = () => {
  const { articles, removeArticle, updateArticle } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  
  const sortedArticles = sortArticlesByDate(articles);

  const handleEdit = (article: Article) => {
    setEditingArticle(article);
    setShowAddForm(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this article?')) {
      removeArticle(id);
    }
  };

  const toggleFeatured = (article: Article) => {
    updateArticle(article.id, { featured: !article.featured });
  };

  const handleFormCancel = () => {
    setShowAddForm(false);
    setEditingArticle(null);
  };

  return (
    <div className="space-y-6">
      {(showAddForm || editingArticle) ? (
        <ArticleForm 
          onCancel={handleFormCancel}
          editArticle={editingArticle || undefined}
        />
      ) : (
        <div className="flex justify-end">
          <Button 
            onClick={() => setShowAddForm(true)}
            leftIcon={<Plus className="h-4 w-4" />}
          >
            Add New Article
          </Button>
        </div>
      )}

      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-800">
            Your LinkedIn Articles
          </h2>
        </CardHeader>
        <CardContent>
          {sortedArticles.length > 0 ? (
            <div className="divide-y divide-gray-100">
              {sortedArticles.map((article) => (
                <div key={article.id} className="py-4 first:pt-0 last:pb-0">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <h3 className="font-medium text-gray-800">{article.title}</h3>
                        <button
                          onClick={() => toggleFeatured(article)}
                          className={`ml-2 ${
                            article.featured ? 'text-yellow-500' : 'text-gray-400'
                          } hover:text-yellow-600 transition-colors`}
                          title={article.featured ? 'Remove from featured' : 'Mark as featured'}
                        >
                          {article.featured ? (
                            <Star className="h-4 w-4 fill-current" />
                          ) : (
                            <StarOff className="h-4 w-4" />
                          )}
                        </button>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        Published on {formatDate(article.publishDate)}
                      </p>
                      <p className="text-gray-600 mt-2">{article.summary}</p>
                      <a 
                        href={article.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:text-blue-800 hover:underline mt-2 inline-block"
                      >
                        View on LinkedIn
                      </a>
                    </div>
                    <div className="flex mt-3 sm:mt-0 space-x-2">
                      <button
                        onClick={() => handleEdit(article)}
                        className="text-gray-500 hover:text-blue-600"
                        title="Edit article"
                      >
                        <Edit2 className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(article.id)}
                        className="text-gray-500 hover:text-red-600"
                        title="Delete article"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>You haven't added any LinkedIn articles yet.</p>
              <Button 
                onClick={() => setShowAddForm(true)}
                variant="outline"
                className="mt-4"
              >
                Add Your First Article
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ArticleList;