import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import Card, { CardHeader, CardContent, CardFooter } from '../common/Card';
import Button from '../common/Button';
import { generateId } from '../../utils/helpers';
import { EmailUpdate } from '../../types';
import { Check, X } from 'lucide-react';

interface EmailFormProps {
  onCancel: () => void;
  editEmail?: EmailUpdate;
}

const EmailForm: React.FC<EmailFormProps> = ({ onCancel, editEmail }) => {
  const { addEmail, updateEmail } = useApp();
  const [formData, setFormData] = useState<Omit<EmailUpdate, 'id'>>({
    subject: editEmail?.subject || '',
    sender: editEmail?.sender || '',
    receivedDate: editEmail?.receivedDate || new Date().toISOString().split('T')[0],
    content: editEmail?.content || '',
    category: editEmail?.category || 'google',
    isRead: editEmail?.isRead ?? true
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is updated
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }
    
    if (!formData.sender.trim()) {
      newErrors.sender = 'Sender is required';
    }
    
    if (!formData.receivedDate) {
      newErrors.receivedDate = 'Received date is required';
    }
    
    if (!formData.content.trim()) {
      newErrors.content = 'Content is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    if (editEmail) {
      updateEmail(editEmail.id, formData);
    } else {
      const newEmail: EmailUpdate = {
        id: generateId(),
        ...formData
      };
      addEmail(newEmail);
    }
    
    onCancel();
  };

  return (
    <Card>
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-800">
          {editEmail ? 'Edit Email Update' : 'Add New Email Update'}
        </h2>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subject
              </label>
              <input
                type="text"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                className={`w-full rounded-md ${
                  errors.subject 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
                placeholder="Email subject"
              />
              {errors.subject && (
                <p className="mt-1 text-sm text-red-600">{errors.subject}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Sender
              </label>
              <input
                type="text"
                name="sender"
                value={formData.sender}
                onChange={handleChange}
                className={`w-full rounded-md ${
                  errors.sender 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
                placeholder="Sender email address"
              />
              {errors.sender && (
                <p className="mt-1 text-sm text-red-600">{errors.sender}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Received Date
              </label>
              <input
                type="date"
                name="receivedDate"
                value={formData.receivedDate}
                onChange={handleChange}
                className={`w-full rounded-md ${
                  errors.receivedDate 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
              />
              {errors.receivedDate && (
                <p className="mt-1 text-sm text-red-600">{errors.receivedDate}</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              >
                <option value="google">Google</option>
                <option value="other">Other</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Content
              </label>
              <textarea
                name="content"
                value={formData.content}
                onChange={handleChange}
                rows={4}
                className={`w-full rounded-md ${
                  errors.content 
                    ? 'border-red-500 focus:border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 focus:border-blue-300 focus:ring-blue-200'
                } shadow-sm focus:ring focus:ring-opacity-50`}
                placeholder="Email content or summary"
              />
              {errors.content && (
                <p className="mt-1 text-sm text-red-600">{errors.content}</p>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isRead"
                name="isRead"
                checked={formData.isRead}
                onChange={handleCheckboxChange}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
              <label htmlFor="isRead" className="text-sm font-medium text-gray-700">
                Mark as read
              </label>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end space-x-3">
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
            leftIcon={<X className="h-4 w-4" />}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            leftIcon={<Check className="h-4 w-4" />}
          >
            {editEmail ? 'Update Email' : 'Add Email'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default EmailForm;