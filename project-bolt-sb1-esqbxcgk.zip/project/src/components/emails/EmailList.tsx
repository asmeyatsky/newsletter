import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import Card, { CardHeader, CardContent } from '../common/Card';
import { formatDate, sortEmailsByDate } from '../../utils/helpers';
import { EmailUpdate } from '../../types';
import Button from '../common/Button';
import { Plus, Edit2, Trash2, Mail, MailOpen } from 'lucide-react';
import EmailForm from './EmailForm';

const EmailList: React.FC = () => {
  const { emails, removeEmail, updateEmail } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingEmail, setEditingEmail] = useState<EmailUpdate | null>(null);
  const [filter, setFilter] = useState<'all' | 'google' | 'other'>('all');
  
  const filteredEmails = sortEmailsByDate(
    filter === 'all' 
      ? emails 
      : emails.filter(email => email.category === filter)
  );

  const handleEdit = (email: EmailUpdate) => {
    setEditingEmail(email);
    setShowAddForm(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this email update?')) {
      removeEmail(id);
    }
  };

  const toggleReadStatus = (email: EmailUpdate) => {
    updateEmail(email.id, { isRead: !email.isRead });
  };

  const handleFormCancel = () => {
    setShowAddForm(false);
    setEditingEmail(null);
  };

  return (
    <div className="space-y-6">
      {(showAddForm || editingEmail) ? (
        <EmailForm 
          onCancel={handleFormCancel}
          editEmail={editingEmail || undefined}
        />
      ) : (
        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            <Button 
              variant={filter === 'all' ? 'primary' : 'outline'} 
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button 
              variant={filter === 'google' ? 'primary' : 'outline'} 
              size="sm"
              onClick={() => setFilter('google')}
            >
              Google
            </Button>
            <Button 
              variant={filter === 'other' ? 'primary' : 'outline'} 
              size="sm"
              onClick={() => setFilter('other')}
            >
              Other
            </Button>
          </div>
          <Button 
            onClick={() => setShowAddForm(true)}
            leftIcon={<Plus className="h-4 w-4" />}
          >
            Add New Email
          </Button>
        </div>
      )}

      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-800">
            Email Updates
          </h2>
        </CardHeader>
        <CardContent>
          {filteredEmails.length > 0 ? (
            <div className="divide-y divide-gray-100">
              {filteredEmails.map((email) => (
                <div key={email.id} className="py-4 first:pt-0 last:pb-0">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <button
                          onClick={() => toggleReadStatus(email)}
                          className={`mr-2 ${
                            email.isRead ? 'text-gray-400' : 'text-blue-500'
                          } hover:text-blue-600 transition-colors`}
                          title={email.isRead ? 'Mark as unread' : 'Mark as read'}
                        >
                          {email.isRead ? (
                            <MailOpen className="h-4 w-4" />
                          ) : (
                            <Mail className="h-4 w-4 fill-current" />
                          )}
                        </button>
                        <h3 className={`font-medium ${email.isRead ? 'text-gray-800' : 'text-black font-semibold'}`}>
                          {email.subject}
                        </h3>
                      </div>
                      <div className="flex items-center text-sm text-gray-500 mt-1 space-x-2">
                        <span>{email.sender}</span>
                        <span>•</span>
                        <span>{formatDate(email.receivedDate)}</span>
                        <span>•</span>
                        <span className={`px-2 py-0.5 text-xs rounded-full ${
                          email.category === 'google' 
                            ? 'bg-blue-50 text-blue-700' 
                            : 'bg-gray-100 text-gray-700'
                        }`}>
                          {email.category === 'google' ? 'Google' : 'Other'}
                        </span>
                      </div>
                      <p className="text-gray-600 mt-2">{email.content}</p>
                    </div>
                    <div className="flex mt-3 sm:mt-0 space-x-2">
                      <button
                        onClick={() => handleEdit(email)}
                        className="text-gray-500 hover:text-blue-600"
                        title="Edit email"
                      >
                        <Edit2 className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(email.id)}
                        className="text-gray-500 hover:text-red-600"
                        title="Delete email"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No email updates found for the selected filter.</p>
              <Button 
                onClick={() => setShowAddForm(true)}
                variant="outline"
                className="mt-4"
              >
                Add Email Update
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default EmailList;