import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import Card, { CardHeader, CardContent } from '../common/Card';
import Button from '../common/Button';
import { Plus, Trash2, MoveUp, MoveDown } from 'lucide-react';
import { generateId } from '../../utils/helpers';
import { NewsletterSection } from '../../types';

const NewsletterEditor: React.FC = () => {
  const { activeTemplate, updateTemplate } = useApp();
  const [newSectionType, setNewSectionType] = useState<'resume' | 'articles' | 'emails' | 'custom'>('resume');

  const handleTemplateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    updateTemplate(activeTemplate.id, { [name]: value });
  };

  const addSection = () => {
    const newSection: NewsletterSection = {
      id: generateId(),
      type: newSectionType,
      title: getDefaultTitleForType(newSectionType),
      layout: 'list',
      showDate: true
    };
    
    updateTemplate(activeTemplate.id, {
      sections: [...activeTemplate.sections, newSection]
    });
  };

  const getDefaultTitleForType = (type: string): string => {
    switch (type) {
      case 'resume': return 'Professional Profile';
      case 'articles': return 'Recent Articles';
      case 'emails': return 'Google Updates';
      case 'custom': return 'Custom Section';
      default: return 'New Section';
    }
  };

  const removeSection = (id: string) => {
    if (activeTemplate.sections.length <= 1) {
      alert('You must have at least one section in your newsletter.');
      return;
    }
    
    updateTemplate(activeTemplate.id, {
      sections: activeTemplate.sections.filter(section => section.id !== id)
    });
  };

  const updateSection = (id: string, data: Partial<NewsletterSection>) => {
    updateTemplate(activeTemplate.id, {
      sections: activeTemplate.sections.map(section => 
        section.id === id ? { ...section, ...data } : section
      )
    });
  };

  const moveSection = (id: string, direction: 'up' | 'down') => {
    const sections = [...activeTemplate.sections];
    const index = sections.findIndex(section => section.id === id);
    
    if (direction === 'up' && index > 0) {
      const temp = sections[index];
      sections[index] = sections[index - 1];
      sections[index - 1] = temp;
      updateTemplate(activeTemplate.id, { sections });
    } else if (direction === 'down' && index < sections.length - 1) {
      const temp = sections[index];
      sections[index] = sections[index + 1];
      sections[index + 1] = temp;
      updateTemplate(activeTemplate.id, { sections });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-800">Template Settings</h2>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Template Name
              </label>
              <input
                type="text"
                name="name"
                value={activeTemplate.name}
                onChange={handleTemplateChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Font Family
              </label>
              <input
                type="text"
                name="fontFamily"
                value={activeTemplate.fontFamily}
                onChange={handleTemplateChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Primary Color
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  name="primaryColor"
                  value={activeTemplate.primaryColor}
                  onChange={handleTemplateChange}
                  className="h-10 w-10 rounded overflow-hidden cursor-pointer"
                />
                <input
                  type="text"
                  name="primaryColor"
                  value={activeTemplate.primaryColor}
                  onChange={handleTemplateChange}
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Secondary Color
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  name="secondaryColor"
                  value={activeTemplate.secondaryColor}
                  onChange={handleTemplateChange}
                  className="h-10 w-10 rounded overflow-hidden cursor-pointer"
                />
                <input
                  type="text"
                  name="secondaryColor"
                  value={activeTemplate.secondaryColor}
                  onChange={handleTemplateChange}
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Newsletter Sections</h2>
          <div className="flex items-center space-x-2">
            <select
              value={newSectionType}
              onChange={(e) => setNewSectionType(e.target.value as any)}
              className="rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 text-sm"
            >
              <option value="resume">Resume Section</option>
              <option value="articles">Articles Section</option>
              <option value="emails">Email Updates Section</option>
              <option value="custom">Custom Section</option>
            </select>
            <Button
              variant="outline"
              size="sm"
              onClick={addSection}
              leftIcon={<Plus className="h-4 w-4" />}
            >
              Add Section
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activeTemplate.sections.map((section, index) => (
              <div key={section.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-500 font-medium">{index + 1}.</span>
                    <select
                      value={section.type}
                      onChange={(e) => updateSection(section.id, { type: e.target.value as any })}
                      className="rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    >
                      <option value="resume">Resume Section</option>
                      <option value="articles">Articles Section</option>
                      <option value="emails">Email Updates Section</option>
                      <option value="custom">Custom Section</option>
                    </select>
                  </div>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => moveSection(section.id, 'up')}
                      disabled={index === 0}
                      className={`p-1 rounded hover:bg-gray-100 ${index === 0 ? 'text-gray-300 cursor-not-allowed' : 'text-gray-600'}`}
                    >
                      <MoveUp className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => moveSection(section.id, 'down')}
                      disabled={index === activeTemplate.sections.length - 1}
                      className={`p-1 rounded hover:bg-gray-100 ${index === activeTemplate.sections.length - 1 ? 'text-gray-300 cursor-not-allowed' : 'text-gray-600'}`}
                    >
                      <MoveDown className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => removeSection(section.id)}
                      className="p-1 rounded hover:bg-red-50 text-red-500"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Section Title
                    </label>
                    <input
                      type="text"
                      value={section.title}
                      onChange={(e) => updateSection(section.id, { title: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Layout
                    </label>
                    <select
                      value={section.layout}
                      onChange={(e) => updateSection(section.id, { layout: e.target.value as any })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    >
                      <option value="list">List</option>
                      <option value="grid">Grid</option>
                      <option value="featured">Featured</option>
                    </select>
                  </div>
                  
                  {(section.type === 'articles' || section.type === 'emails') && (
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`showDate-${section.id}`}
                        checked={section.showDate ?? true}
                        onChange={(e) => updateSection(section.id, { showDate: e.target.checked })}
                        className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                      />
                      <label htmlFor={`showDate-${section.id}`} className="text-sm font-medium text-gray-700">
                        Show dates
                      </label>
                    </div>
                  )}
                  
                  {section.type === 'custom' && (
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Custom Content
                      </label>
                      <textarea
                        value={section.content || ''}
                        onChange={(e) => updateSection(section.id, { content: e.target.value })}
                        rows={4}
                        className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                        placeholder="Enter custom content here..."
                      />
                    </div>
                  )}
                </div>
              </div>
            ))}
            
            {activeTemplate.sections.length === 0 && (
              <div className="text-center py-6 text-gray-500">
                No sections added yet. Add a section to begin designing your newsletter.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NewsletterEditor;