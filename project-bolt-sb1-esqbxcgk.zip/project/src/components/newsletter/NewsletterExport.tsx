import React, { useState } from 'react';
import Card, { CardHeader, CardContent } from '../common/Card';
import Button from '../common/Button';
import { Download, Mail, Copy, Check } from 'lucide-react';

const NewsletterExport: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [error, setError] = useState('');

  const handleExportPDF = () => {
    window.print();
  };

  const handleCopyHTML = () => {
    // In a real app, this would generate and copy HTML
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const validateEmail = (email: string): boolean => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const handleSendEmail = () => {
    setError('');
    
    if (!recipientEmail) {
      setError('Please enter a recipient email address');
      return;
    }
    
    if (!validateEmail(recipientEmail)) {
      setError('Please enter a valid email address');
      return;
    }
    
    // In a real app, this would send the newsletter via email
    setEmailSent(true);
    setTimeout(() => {
      setEmailSent(false);
      setRecipientEmail('');
    }, 3000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-800">Export Newsletter</h2>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="text-md font-medium text-gray-800 mb-3">Download as PDF</h3>
              <p className="text-gray-600 mb-3">
                Export your newsletter as a PDF file that you can share or print.
              </p>
              <Button 
                onClick={handleExportPDF}
                leftIcon={<Download className="h-4 w-4" />}
              >
                Export as PDF
              </Button>
            </div>
            
            <div className="border-t border-gray-100 pt-6">
              <h3 className="text-md font-medium text-gray-800 mb-3">Copy HTML</h3>
              <p className="text-gray-600 mb-3">
                Copy the HTML code of your newsletter to paste it into an email or website.
              </p>
              <Button 
                onClick={handleCopyHTML}
                variant="outline"
                leftIcon={copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              >
                {copied ? 'Copied!' : 'Copy HTML'}
              </Button>
            </div>
            
            <div className="border-t border-gray-100 pt-6">
              <h3 className="text-md font-medium text-gray-800 mb-3">Send via Email</h3>
              <p className="text-gray-600 mb-3">
                Send the newsletter directly to someone's email address.
              </p>
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                <input
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="recipient@example.com"
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                />
                <Button 
                  onClick={handleSendEmail}
                  variant="secondary"
                  leftIcon={emailSent ? <Check className="h-4 w-4" /> : <Mail className="h-4 w-4" />}
                  disabled={emailSent}
                >
                  {emailSent ? 'Sent!' : 'Send Email'}
                </Button>
              </div>
              {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NewsletterExport;