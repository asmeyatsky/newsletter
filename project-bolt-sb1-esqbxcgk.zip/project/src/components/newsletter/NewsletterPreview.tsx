import React from 'react';
import { useApp } from '../../contexts/AppContext';
import { formatDate, getSectionItems, truncateText } from '../../utils/helpers';
import { Article, EmailUpdate } from '../../types';

const NewsletterPreview: React.FC = () => {
  const { resume, articles, emails, activeTemplate } = useApp();
  
  return (
    <div className="bg-white border border-gray-200 shadow-sm rounded-lg overflow-hidden max-w-4xl mx-auto">
      <div className="p-1">
        <div
          style={{
            fontFamily: activeTemplate.fontFamily,
            color: '#333',
          }}
        >
          {/* Newsletter Header */}
          <div 
            style={{ backgroundColor: activeTemplate.primaryColor }} 
            className="px-8 py-12 text-white"
          >
            <h1 className="text-3xl font-bold mb-2">{resume.name}</h1>
            <p className="text-xl opacity-90">{resume.title} — Newsletter</p>
          </div>

          {/* Newsletter Sections */}
          <div className="p-8">
            {activeTemplate.sections.map((section) => {
              if (section.type === 'resume') {
                return (
                  <div key={section.id} className="mb-10">
                    <h2 
                      className="text-xl font-bold mb-4 pb-2 border-b-2" 
                      style={{ borderColor: activeTemplate.secondaryColor }}
                    >
                      {section.title}
                    </h2>
                    <div className="prose max-w-none">
                      <p className="mb-4">{resume.summary}</p>
                      
                      {resume.experience.length > 0 && (
                        <div className="mb-4">
                          <h3 className="text-lg font-semibold mb-2">Experience</h3>
                          <div className="space-y-3">
                            {resume.experience.slice(0, 2).map((exp) => (
                              <div key={exp.id}>
                                <div className="font-medium">{exp.title} at {exp.company}</div>
                                <div className="text-sm text-gray-600">
                                  {formatDate(exp.startDate)} — {exp.endDate ? formatDate(exp.endDate) : 'Present'}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {resume.skills.length > 0 && (
                        <div>
                          <h3 className="text-lg font-semibold mb-2">Skills</h3>
                          <div className="flex flex-wrap gap-2">
                            {resume.skills.map((skill, index) => (
                              <span 
                                key={index}
                                style={{ 
                                  backgroundColor: `${activeTemplate.secondaryColor}20`, 
                                  color: activeTemplate.secondaryColor 
                                }}
                                className="px-3 py-1 rounded-full text-sm"
                              >
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              }
              
              if (section.type === 'articles') {
                const sectionItems = getSectionItems(section, articles, []) as Article[];
                
                return (
                  <div key={section.id} className="mb-10">
                    <h2 
                      className="text-xl font-bold mb-4 pb-2 border-b-2" 
                      style={{ borderColor: activeTemplate.secondaryColor }}
                    >
                      {section.title}
                    </h2>
                    
                    {section.layout === 'grid' ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {sectionItems.map((article) => (
                          <div key={article.id} className="border border-gray-100 rounded-lg p-4 shadow-sm">
                            <h3 className="font-medium text-lg mb-1">{article.title}</h3>
                            {section.showDate && (
                              <p className="text-sm text-gray-600 mb-2">
                                {formatDate(article.publishDate)}
                              </p>
                            )}
                            <p className="text-gray-700 mb-2">{truncateText(article.summary, 100)}</p>
                            <a 
                              href={article.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              style={{ color: activeTemplate.primaryColor }}
                              className="text-sm font-medium hover:underline"
                            >
                              Read More
                            </a>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {sectionItems.map((article) => (
                          <div key={article.id} className="border-b border-gray-100 pb-4">
                            <h3 className="font-medium text-lg mb-1">{article.title}</h3>
                            {section.showDate && (
                              <p className="text-sm text-gray-600 mb-2">
                                {formatDate(article.publishDate)}
                              </p>
                            )}
                            <p className="text-gray-700 mb-2">{article.summary}</p>
                            <a 
                              href={article.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              style={{ color: activeTemplate.primaryColor }}
                              className="text-sm font-medium hover:underline"
                            >
                              Read More
                            </a>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              }
              
              if (section.type === 'emails') {
                const sectionItems = getSectionItems(section, [], emails) as EmailUpdate[];
                const googleEmails = sectionItems.filter(email => email.category === 'google');
                
                return (
                  <div key={section.id} className="mb-10">
                    <h2 
                      className="text-xl font-bold mb-4 pb-2 border-b-2" 
                      style={{ borderColor: activeTemplate.secondaryColor }}
                    >
                      {section.title}
                    </h2>
                    
                    <div className="space-y-4">
                      {googleEmails.map((email) => (
                        <div key={email.id} className="border-l-4 pl-4 py-1" style={{ borderColor: activeTemplate.secondaryColor }}>
                          <h3 className="font-medium text-lg mb-1">{email.subject}</h3>
                          {section.showDate && (
                            <p className="text-sm text-gray-600 mb-2">
                              {formatDate(email.receivedDate)} • {email.sender}
                            </p>
                          )}
                          <p className="text-gray-700">{email.content}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              }
              
              return null;
            })}
          </div>

          {/* Newsletter Footer */}
          <div className="px-8 py-6 bg-gray-50 text-center text-gray-600 text-sm">
            <p>
              This newsletter was created by {resume.name}. 
              {resume.email && ` Contact me at ${resume.email}`}
            </p>
            <p className="mt-2">
              To unsubscribe or manage your preferences, click here.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsletterPreview;