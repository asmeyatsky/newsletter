import React from 'react';
import { useApp } from '../../contexts/AppContext';
import Card, { CardHeader, CardContent } from '../common/Card';
import Button from '../common/Button';
import { Plus, Trash2 } from 'lucide-react';
import { generateId } from '../../utils/helpers';
import { ExperienceItem, EducationItem } from '../../types';

const ResumeForm: React.FC = () => {
  const { resume, updateResume } = useApp();

  const handleBasicInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    updateResume({ [name]: value });
  };

  const handleSkillChange = (index: number, value: string) => {
    const updatedSkills = [...resume.skills];
    updatedSkills[index] = value;
    updateResume({ skills: updatedSkills });
  };

  const addSkill = () => {
    updateResume({ skills: [...resume.skills, ''] });
  };

  const removeSkill = (index: number) => {
    const updatedSkills = [...resume.skills];
    updatedSkills.splice(index, 1);
    updateResume({ skills: updatedSkills });
  };

  const addExperience = () => {
    const newExperience: ExperienceItem = {
      id: generateId(),
      company: '',
      title: '',
      startDate: '',
      endDate: null,
      description: '',
      highlights: []
    };
    updateResume({ experience: [...resume.experience, newExperience] });
  };

  const updateExperience = (id: string, data: Partial<ExperienceItem>) => {
    const updatedExperience = resume.experience.map(exp =>
      exp.id === id ? { ...exp, ...data } : exp
    );
    updateResume({ experience: updatedExperience });
  };

  const removeExperience = (id: string) => {
    const updatedExperience = resume.experience.filter(exp => exp.id !== id);
    updateResume({ experience: updatedExperience });
  };

  const addEducation = () => {
    const newEducation: EducationItem = {
      id: generateId(),
      institution: '',
      degree: '',
      field: '',
      graduationDate: ''
    };
    updateResume({ education: [...resume.education, newEducation] });
  };

  const updateEducation = (id: string, data: Partial<EducationItem>) => {
    const updatedEducation = resume.education.map(edu =>
      edu.id === id ? { ...edu, ...data } : edu
    );
    updateResume({ education: updatedEducation });
  };

  const removeEducation = (id: string) => {
    const updatedEducation = resume.education.filter(edu => edu.id !== id);
    updateResume({ education: updatedEducation });
  };

  return (
    <div className="space-y-8">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-800">Basic Information</h2>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Full Name
              </label>
              <input
                type="text"
                name="name"
                value={resume.name}
                onChange={handleBasicInfoChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job Title
              </label>
              <input
                type="text"
                name="title"
                value={resume.title}
                onChange={handleBasicInfoChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={resume.email}
                onChange={handleBasicInfoChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone
              </label>
              <input
                type="tel"
                name="phone"
                value={resume.phone || ''}
                onChange={handleBasicInfoChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Website
              </label>
              <input
                type="url"
                name="website"
                value={resume.website || ''}
                onChange={handleBasicInfoChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Professional Summary
              </label>
              <textarea
                name="summary"
                value={resume.summary}
                onChange={handleBasicInfoChange}
                rows={4}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Experience */}
      <Card>
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Work Experience</h2>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={addExperience}
            leftIcon={<Plus className="h-4 w-4" />}
          >
            Add Experience
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {resume.experience.map((exp) => (
              <div key={exp.id} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-medium text-gray-800">Experience Details</h3>
                  <button
                    onClick={() => removeExperience(exp.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Company
                    </label>
                    <input
                      type="text"
                      value={exp.company}
                      onChange={(e) => updateExperience(exp.id, { company: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Job Title
                    </label>
                    <input
                      type="text"
                      value={exp.title}
                      onChange={(e) => updateExperience(exp.id, { title: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={exp.startDate}
                      onChange={(e) => updateExperience(exp.id, { startDate: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      End Date (leave empty for current position)
                    </label>
                    <input
                      type="date"
                      value={exp.endDate || ''}
                      onChange={(e) => updateExperience(exp.id, { endDate: e.target.value || null })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <textarea
                      value={exp.description}
                      onChange={(e) => updateExperience(exp.id, { description: e.target.value })}
                      rows={3}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                </div>
              </div>
            ))}

            {resume.experience.length === 0 && (
              <div className="text-center py-6 text-gray-500">
                No experience added yet. Click the button above to add work experience.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Education */}
      <Card>
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Education</h2>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={addEducation}
            leftIcon={<Plus className="h-4 w-4" />}
          >
            Add Education
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {resume.education.map((edu) => (
              <div key={edu.id} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-medium text-gray-800">Education Details</h3>
                  <button
                    onClick={() => removeEducation(edu.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Institution
                    </label>
                    <input
                      type="text"
                      value={edu.institution}
                      onChange={(e) => updateEducation(edu.id, { institution: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Degree
                    </label>
                    <input
                      type="text"
                      value={edu.degree}
                      onChange={(e) => updateEducation(edu.id, { degree: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Field of Study
                    </label>
                    <input
                      type="text"
                      value={edu.field}
                      onChange={(e) => updateEducation(edu.id, { field: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Graduation Date
                    </label>
                    <input
                      type="date"
                      value={edu.graduationDate}
                      onChange={(e) => updateEducation(edu.id, { graduationDate: e.target.value })}
                      className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                  </div>
                </div>
              </div>
            ))}

            {resume.education.length === 0 && (
              <div className="text-center py-6 text-gray-500">
                No education added yet. Click the button above to add education.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Skills */}
      <Card>
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">Skills</h2>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={addSkill}
            leftIcon={<Plus className="h-4 w-4" />}
          >
            Add Skill
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {resume.skills.map((skill, index) => (
              <div key={index} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={skill}
                  onChange={(e) => handleSkillChange(index, e.target.value)}
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  placeholder="Enter skill"
                />
                <button
                  onClick={() => removeSkill(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            ))}

            {resume.skills.length === 0 && (
              <div className="text-center py-6 text-gray-500">
                No skills added yet. Click the button above to add skills.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ResumeForm;