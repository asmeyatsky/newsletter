import React from 'react';
import { useApp } from '../../contexts/AppContext';
import { formatDate } from '../../utils/helpers';
import Card from '../common/Card';

const ResumePreview: React.FC = () => {
  const { resume } = useApp();

  return (
    <Card className="resume-preview print:shadow-none print:border-none">
      <div className="p-8 max-w-4xl mx-auto">
        {/* Header */}
        <header className="text-center mb-8">
          <h1 className="text-3xl font-bold text-blue-900">{resume.name}</h1>
          <p className="text-lg text-gray-600 mt-1">{resume.title}</p>
          
          <div className="mt-3 flex flex-wrap justify-center gap-x-4 gap-y-2 text-sm text-gray-600">
            {resume.email && (
              <div>{resume.email}</div>
            )}
            {resume.phone && (
              <div>{resume.phone}</div>
            )}
            {resume.website && (
              <div>{resume.website}</div>
            )}
          </div>
        </header>

        {/* Summary */}
        {resume.summary && (
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-blue-900 border-b border-gray-200 pb-2 mb-3">
              Professional Summary
            </h2>
            <p className="text-gray-700 leading-relaxed">{resume.summary}</p>
          </section>
        )}

        {/* Experience */}
        {resume.experience.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-blue-900 border-b border-gray-200 pb-2 mb-4">
              Work Experience
            </h2>
            <div className="space-y-6">
              {resume.experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-baseline">
                    <h3 className="text-lg font-medium text-gray-800">{exp.title}</h3>
                    <p className="text-gray-600 text-sm">
                      {formatDate(exp.startDate)} — {exp.endDate ? formatDate(exp.endDate) : 'Present'}
                    </p>
                  </div>
                  <p className="text-gray-700 font-medium mt-1">{exp.company}</p>
                  <p className="text-gray-600 mt-2">{exp.description}</p>
                  
                  {exp.highlights && exp.highlights.length > 0 && (
                    <ul className="mt-2 list-disc list-inside text-gray-600 space-y-1">
                      {exp.highlights.map((highlight, index) => (
                        <li key={index}>{highlight}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Education */}
        {resume.education.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-blue-900 border-b border-gray-200 pb-2 mb-4">
              Education
            </h2>
            <div className="space-y-4">
              {resume.education.map((edu) => (
                <div key={edu.id}>
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-baseline">
                    <h3 className="text-lg font-medium text-gray-800">{edu.institution}</h3>
                    <p className="text-gray-600 text-sm">
                      {formatDate(edu.graduationDate)}
                    </p>
                  </div>
                  <p className="text-gray-700 mt-1">
                    {edu.degree}{edu.field ? `, ${edu.field}` : ''}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Skills */}
        {resume.skills.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold text-blue-900 border-b border-gray-200 pb-2 mb-3">
              Skills
            </h2>
            <div className="flex flex-wrap gap-2">
              {resume.skills.map((skill, index) => (
                <span 
                  key={index}
                  className="bg-blue-50 text-blue-800 px-3 py-1 rounded-full text-sm"
                >
                  {skill}
                </span>
              ))}
            </div>
          </section>
        )}
      </div>
    </Card>
  );
};

export default ResumePreview;