import React, { createContext, useContext, useState, ReactNode } from 'react';
import { 
  ResumeData, 
  Article, 
  EmailUpdate, 
  NewsletterTemplate 
} from '../types';
import { 
  sampleResume, 
  sampleArticles, 
  sampleEmails, 
  sampleTemplate 
} from '../data/sampleData';

interface AppContextType {
  resume: ResumeData;
  updateResume: (data: Partial<ResumeData>) => void;
  
  articles: Article[];
  addArticle: (article: Article) => void;
  removeArticle: (id: string) => void;
  updateArticle: (id: string, data: Partial<Article>) => void;
  
  emails: EmailUpdate[];
  addEmail: (email: EmailUpdate) => void;
  removeEmail: (id: string) => void;
  updateEmail: (id: string, data: Partial<EmailUpdate>) => void;
  
  templates: NewsletterTemplate[];
  activeTemplate: NewsletterTemplate;
  setActiveTemplate: (template: NewsletterTemplate) => void;
  updateTemplate: (id: string, data: Partial<NewsletterTemplate>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [resume, setResume] = useState<ResumeData>(sampleResume);
  const [articles, setArticles] = useState<Article[]>(sampleArticles);
  const [emails, setEmails] = useState<EmailUpdate[]>(sampleEmails);
  const [templates, setTemplates] = useState<NewsletterTemplate[]>([sampleTemplate]);
  const [activeTemplate, setActiveTemplate] = useState<NewsletterTemplate>(sampleTemplate);

  const updateResume = (data: Partial<ResumeData>) => {
    setResume(prev => ({ ...prev, ...data }));
  };

  const addArticle = (article: Article) => {
    setArticles(prev => [...prev, article]);
  };

  const removeArticle = (id: string) => {
    setArticles(prev => prev.filter(article => article.id !== id));
  };

  const updateArticle = (id: string, data: Partial<Article>) => {
    setArticles(prev => 
      prev.map(article => 
        article.id === id ? { ...article, ...data } : article
      )
    );
  };

  const addEmail = (email: EmailUpdate) => {
    setEmails(prev => [...prev, email]);
  };

  const removeEmail = (id: string) => {
    setEmails(prev => prev.filter(email => email.id !== id));
  };

  const updateEmail = (id: string, data: Partial<EmailUpdate>) => {
    setEmails(prev => 
      prev.map(email => 
        email.id === id ? { ...email, ...data } : email
      )
    );
  };

  const updateTemplate = (id: string, data: Partial<NewsletterTemplate>) => {
    setTemplates(prev => 
      prev.map(template => 
        template.id === id ? { ...template, ...data } : template
      )
    );
    
    if (activeTemplate.id === id) {
      setActiveTemplate(prev => ({ ...prev, ...data }));
    }
  };

  const value: AppContextType = {
    resume,
    updateResume,
    articles,
    addArticle,
    removeArticle,
    updateArticle,
    emails,
    addEmail,
    removeEmail,
    updateEmail,
    templates,
    activeTemplate,
    setActiveTemplate,
    updateTemplate
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};