import { Article, EmailUpdate, ResumeData, NewsletterTemplate } from '../types';
import { generateId } from '../utils/helpers';

export const sampleResume: ResumeData = {
  name: 'Alex Johnson',
  title: 'Senior Software Engineer',
  email: 'alex.johnson@example.com',
  phone: '(555) 123-4567',
  website: 'alexjohnson.dev',
  summary: 'Experienced software engineer with a passion for building intuitive user interfaces and scalable applications. Specialized in React, TypeScript, and modern web technologies.',
  experience: [
    {
      id: generateId(),
      company: 'Tech Innovations Inc',
      title: 'Senior Software Engineer',
      startDate: '2021-03-01',
      endDate: null,
      description: 'Lead developer for customer-facing web applications',
      highlights: [
        'Rebuilt the company website using React and TypeScript, improving performance by 40%',
        'Implemented CI/CD pipeline, reducing deployment time by 60%',
        'Mentored junior developers and conducted code reviews'
      ]
    },
    {
      id: generateId(),
      company: 'Digital Solutions LLC',
      title: 'Software Engineer',
      startDate: '2018-06-01',
      endDate: '2021-02-28',
      description: 'Worked on various web development projects',
      highlights: [
        'Developed and maintained multiple client websites using React',
        'Integrated RESTful APIs with frontend applications',
        'Implemented responsive designs for mobile and desktop'
      ]
    }
  ],
  education: [
    {
      id: generateId(),
      institution: 'University of Technology',
      degree: 'Master of Science',
      field: 'Computer Science',
      graduationDate: '2018-05-15'
    },
    {
      id: generateId(),
      institution: 'State University',
      degree: 'Bachelor of Science',
      field: 'Software Engineering',
      graduationDate: '2016-05-20'
    }
  ],
  skills: ['React', 'TypeScript', 'JavaScript', 'HTML/CSS', 'Node.js', 'GraphQL', 'REST APIs', 'Git', 'Agile/Scrum']
};

export const sampleArticles: Article[] = [
  {
    id: generateId(),
    title: 'The Future of Web Development: What to Expect in 2025',
    summary: 'An exploration of upcoming trends in web development, including AI integration, WebAssembly advances, and the evolution of JavaScript frameworks.',
    publishDate: '2023-11-15',
    url: 'https://linkedin.com/pulse/future-web-development-alex-johnson',
    source: 'linkedin',
    featured: true
  },
  {
    id: generateId(),
    title: 'Optimizing React Performance: Advanced Techniques',
    summary: 'A deep dive into performance optimization in React applications, covering memoization, code splitting, and efficient state management.',
    publishDate: '2023-09-22',
    url: 'https://linkedin.com/pulse/optimizing-react-performance-alex-johnson',
    source: 'linkedin',
    featured: false
  },
  {
    id: generateId(),
    title: 'Building Accessible Web Applications: A Complete Guide',
    summary: 'Comprehensive strategies for creating web applications that are accessible to all users, including those with disabilities.',
    publishDate: '2023-07-05',
    url: 'https://linkedin.com/pulse/building-accessible-web-applications-alex-johnson',
    source: 'linkedin',
    featured: true
  },
];

export const sampleEmails: EmailUpdate[] = [
  {
    id: generateId(),
    subject: 'Google Cloud Platform: New Features Announcement',
    sender: 'updates@google.com',
    receivedDate: '2023-12-01',
    content: 'We are excited to announce new features in Google Cloud Platform, including enhanced AI capabilities and improved security measures.',
    category: 'google',
    isRead: true
  },
  {
    id: generateId(),
    subject: 'Google Workspace Updates: December 2023',
    sender: 'workspace-updates@google.com',
    receivedDate: '2023-12-05',
    content: 'Check out the latest updates to Google Workspace applications, including new collaboration features in Google Docs and enhanced meeting capabilities in Google Meet.',
    category: 'google',
    isRead: false
  },
  {
    id: generateId(),
    subject: 'Google Developer Newsletter: Latest Tools and Resources',
    sender: 'dev-newsletter@google.com',
    receivedDate: '2023-11-28',
    content: 'Stay updated with the latest developer tools, resources, and events from Google. This month features new Flutter updates and Android development best practices.',
    category: 'google',
    isRead: true
  },
];

export const sampleTemplate: NewsletterTemplate = {
  id: generateId(),
  name: 'Professional Update',
  primaryColor: '#1E3A8A',
  secondaryColor: '#0D9488',
  fontFamily: 'Inter, sans-serif',
  sections: [
    {
      id: generateId(),
      type: 'resume',
      title: 'Professional Profile',
      layout: 'featured'
    },
    {
      id: generateId(),
      type: 'articles',
      title: 'Recent Articles',
      showDate: true,
      layout: 'grid'
    },
    {
      id: generateId(),
      type: 'emails',
      title: 'Google Updates',
      showDate: true,
      layout: 'list'
    }
  ]
};