import React from 'react';
import ArticleList from '../components/articles/ArticleList';

const ArticlesPage: React.FC = () => {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">LinkedIn Articles</h1>
        <p className="text-gray-600 mt-1">
          Manage your professional articles from LinkedIn to include in your newsletter.
        </p>
      </div>

      <ArticleList />
    </div>
  );
};

export default ArticlesPage;