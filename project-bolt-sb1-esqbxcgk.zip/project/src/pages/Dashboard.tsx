import React from 'react';
import { useApp } from '../contexts/AppContext';
import Card, { CardHeader, CardContent } from '../components/common/Card';
import { FileText, Linkedin, Mail, LayoutTemplate } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatDate } from '../utils/helpers';

const Dashboard: React.FC = () => {
  const { resume, articles, emails } = useApp();
  
  const featuredArticles = articles.filter(article => article.featured);
  const recentEmails = emails
    .filter(email => email.category === 'google')
    .sort((a, b) => new Date(b.receivedDate).getTime() - new Date(a.receivedDate).getTime())
    .slice(0, 3);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Welcome, {resume.name}</h1>
        <p className="text-gray-600 mt-1">
          Manage your newsletter content and create professional updates with ease.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-blue-50 rounded-lg p-5 border border-blue-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-blue-800 text-sm font-medium">Resume</p>
              <p className="text-3xl font-bold text-blue-900 mt-1">1</p>
            </div>
            <div className="bg-blue-100 rounded-full p-2">
              <FileText className="h-6 w-6 text-blue-700" />
            </div>
          </div>
          <p className="text-blue-700 text-sm mt-3">
            {resume.title} with {resume.experience.length} experience entries
          </p>
        </div>

        <div className="bg-indigo-50 rounded-lg p-5 border border-indigo-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-indigo-800 text-sm font-medium">LinkedIn Articles</p>
              <p className="text-3xl font-bold text-indigo-900 mt-1">{articles.length}</p>
            </div>
            <div className="bg-indigo-100 rounded-full p-2">
              <Linkedin className="h-6 w-6 text-indigo-700" />
            </div>
          </div>
          <p className="text-indigo-700 text-sm mt-3">
            {featuredArticles.length} featured articles
          </p>
        </div>

        <div className="bg-teal-50 rounded-lg p-5 border border-teal-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-teal-800 text-sm font-medium">Email Updates</p>
              <p className="text-3xl font-bold text-teal-900 mt-1">{emails.length}</p>
            </div>
            <div className="bg-teal-100 rounded-full p-2">
              <Mail className="h-6 w-6 text-teal-700" />
            </div>
          </div>
          <p className="text-teal-700 text-sm mt-3">
            {emails.filter(e => e.category === 'google').length} Google-related updates
          </p>
        </div>

        <div className="bg-emerald-50 rounded-lg p-5 border border-emerald-100">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-emerald-800 text-sm font-medium">Templates</p>
              <p className="text-3xl font-bold text-emerald-900 mt-1">1</p>
            </div>
            <div className="bg-emerald-100 rounded-full p-2">
              <LayoutTemplate className="h-6 w-6 text-emerald-700" />
            </div>
          </div>
          <p className="text-emerald-700 text-sm mt-3">
            1 active newsletter template
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Recent Articles</h2>
            <Link to="/articles" className="text-sm text-blue-600 hover:text-blue-800 hover:underline">
              View All
            </Link>
          </CardHeader>
          <CardContent>
            {articles.length > 0 ? (
              <div className="divide-y divide-gray-100">
                {articles.slice(0, 3).map(article => (
                  <div key={article.id} className="py-3 first:pt-0 last:pb-0">
                    <h3 className="font-medium text-gray-800">
                      {article.title}
                      {article.featured && (
                        <span className="ml-2 px-2 py-0.5 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                          Featured
                        </span>
                      )}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">
                      Published on {formatDate(article.publishDate)}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500">
                <p>No articles added yet.</p>
                <Link 
                  to="/articles" 
                  className="text-blue-600 hover:text-blue-800 hover:underline mt-2 inline-block"
                >
                  Add your first article
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Google Updates</h2>
            <Link to="/emails" className="text-sm text-blue-600 hover:text-blue-800 hover:underline">
              View All
            </Link>
          </CardHeader>
          <CardContent>
            {recentEmails.length > 0 ? (
              <div className="divide-y divide-gray-100">
                {recentEmails.map(email => (
                  <div key={email.id} className="py-3 first:pt-0 last:pb-0">
                    <h3 className="font-medium text-gray-800">{email.subject}</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      {formatDate(email.receivedDate)} • {email.sender}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500">
                <p>No Google updates added yet.</p>
                <Link 
                  to="/emails" 
                  className="text-blue-600 hover:text-blue-800 hover:underline mt-2 inline-block"
                >
                  Add your first update
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;