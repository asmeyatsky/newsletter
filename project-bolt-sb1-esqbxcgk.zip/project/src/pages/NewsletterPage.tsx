import React, { useState } from 'react';
import Button from '../components/common/Button';
import NewsletterEditor from '../components/newsletter/NewsletterEditor';
import NewsletterPreview from '../components/newsletter/NewsletterPreview';
import NewsletterExport from '../components/newsletter/NewsletterExport';
import { Settings, Eye, Send } from 'lucide-react';

const NewsletterPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'edit' | 'preview' | 'export'>('edit');

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Newsletter</h1>
        <p className="text-gray-600 mt-1">
          Create and customize your professional newsletter.
        </p>
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        <Button
          variant={activeTab === 'edit' ? 'primary' : 'outline'}
          onClick={() => setActiveTab('edit')}
          leftIcon={<Settings className="h-4 w-4" />}
        >
          Edit Template
        </Button>
        <Button
          variant={activeTab === 'preview' ? 'primary' : 'outline'}
          onClick={() => setActiveTab('preview')}
          leftIcon={<Eye className="h-4 w-4" />}
        >
          Preview
        </Button>
        <Button
          variant={activeTab === 'export' ? 'primary' : 'outline'}
          onClick={() => setActiveTab('export')}
          leftIcon={<Send className="h-4 w-4" />}
        >
          Export
        </Button>
      </div>

      {activeTab === 'edit' && <NewsletterEditor />}
      {activeTab === 'preview' && <NewsletterPreview />}
      {activeTab === 'export' && <NewsletterExport />}
    </div>
  );
};

export default NewsletterPage;