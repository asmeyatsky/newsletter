import React, { useState } from 'react';
import Button from '../components/common/Button';
import ResumeForm from '../components/resume/ResumeForm';
import ResumePreview from '../components/resume/ResumePreview';
import { Pencil, Eye } from 'lucide-react';

const ResumePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Resume</h1>
        <p className="text-gray-600 mt-1">
          Manage your professional information for your newsletter.
        </p>
      </div>

      <div className="mb-6 flex space-x-4">
        <Button
          variant={activeTab === 'edit' ? 'primary' : 'outline'}
          onClick={() => setActiveTab('edit')}
          leftIcon={<Pencil className="h-4 w-4" />}
        >
          Edit
        </Button>
        <Button
          variant={activeTab === 'preview' ? 'primary' : 'outline'}
          onClick={() => setActiveTab('preview')}
          leftIcon={<Eye className="h-4 w-4" />}
        >
          Preview
        </Button>
      </div>

      {activeTab === 'edit' ? <ResumeForm /> : <ResumePreview />}
    </div>
  );
};

export default ResumePage;