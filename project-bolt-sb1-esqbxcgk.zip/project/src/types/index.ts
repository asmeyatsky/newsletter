export interface ResumeData {
  name: string;
  title: string;
  email: string;
  phone?: string;
  website?: string;
  summary: string;
  experience: ExperienceItem[];
  education: EducationItem[];
  skills: string[];
}

export interface ExperienceItem {
  id: string;
  company: string;
  title: string;
  startDate: string;
  endDate: string | null;
  description: string;
  highlights?: string[];
}

export interface EducationItem {
  id: string;
  institution: string;
  degree: string;
  field: string;
  graduationDate: string;
}

export interface Article {
  id: string;
  title: string;
  summary: string;
  publishDate: string;
  url: string;
  source: 'linkedin';
  featured: boolean;
}

export interface EmailUpdate {
  id: string;
  subject: string;
  sender: string;
  receivedDate: string;
  content: string;
  category: 'google' | 'other';
  isRead: boolean;
}

export interface NewsletterTemplate {
  id: string;
  name: string;
  headerImage?: string;
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
  sections: NewsletterSection[];
}

export interface NewsletterSection {
  id: string;
  type: 'resume' | 'articles' | 'emails' | 'custom';
  title: string;
  content?: string;
  items?: (Article | EmailUpdate)[];
  showDate?: boolean;
  layout: 'list' | 'grid' | 'featured';
}