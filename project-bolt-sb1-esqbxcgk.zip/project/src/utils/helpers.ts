import { Article, EmailUpdate, NewsletterSection } from '../types';

/**
 * Format a date string to a more readable format
 * @param dateString - ISO date string
 * @returns Formatted date string (e.g., "May 15, 2023")
 */
export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

/**
 * Sort articles by publish date (newest first)
 */
export const sortArticlesByDate = (articles: Article[]): Article[] => {
  return [...articles].sort((a, b) => 
    new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
  );
};

/**
 * Sort emails by received date (newest first)
 */
export const sortEmailsByDate = (emails: EmailUpdate[]): EmailUpdate[] => {
  return [...emails].sort((a, b) => 
    new Date(b.receivedDate).getTime() - new Date(a.receivedDate).getTime()
  );
};

/**
 * Filter emails by category
 */
export const filterEmailsByCategory = (
  emails: EmailUpdate[], 
  category: 'google' | 'other' | 'all'
): EmailUpdate[] => {
  if (category === 'all') return emails;
  return emails.filter(email => email.category === category);
};

/**
 * Generate a unique ID
 */
export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 15);
};

/**
 * Extract section items based on section type and available content
 */
export const getSectionItems = (
  section: NewsletterSection,
  articles: Article[],
  emails: EmailUpdate[]
): (Article | EmailUpdate)[] => {
  switch (section.type) {
    case 'articles':
      return sortArticlesByDate(articles);
    case 'emails':
      return sortEmailsByDate(
        filterEmailsByCategory(emails, 'google')
      );
    default:
      return section.items || [];
  }
};

/**
 * Truncate text with ellipsis
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};